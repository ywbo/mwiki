package com.fc.v2.mapper.auto;

import com.fc.v2.model.auto.MybatisTest;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 自动生成测试 Mapper 接口
 * </p>
 *
 * @author v2
 * @since 2023-04-07
 */
public interface MybatisTestMapper extends BaseMapper<MybatisTest> {

}
