package com.fc.v2.service.plus;

import com.fc.v2.model.auto.MybatisTest;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 自动生成测试 服务类
 * </p>
 *
 * @author v2
 * @since 2023-04-07
 */
public interface IMybatisTestService extends IService<MybatisTest> {

}
